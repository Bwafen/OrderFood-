INSERT INTO categories(id,name) VALUES(null,'légumes'),(null,'fruits'),(null,'spicy');
INSERT INTO fooditems(id,description,price) VALUES(null,'Kebab',4.85),(null,'Couscous',14.25),(null,'Burger',3.50),(null,'Salade',2.90);
