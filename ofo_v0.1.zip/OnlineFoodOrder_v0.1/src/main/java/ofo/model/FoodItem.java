package ofo.model;

//import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="fooditems")
public class FoodItem extends Sellable {
	
	@ManyToMany
	private List<Category> categories;
	
	/*public FoodItem() {
		this.categories = new ArrayList<Category>();
	}*/

	public List<Category> getCategories() {
		return categories;
	}

	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}

	
}
