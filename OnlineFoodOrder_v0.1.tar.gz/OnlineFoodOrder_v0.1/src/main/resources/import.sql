INSERT INTO categories(id,name) VALUES(null,'légumes'),(null,'fruits'),(null,'spicy');
INSERT INTO fooditems(id,description,price,quantity) VALUES(null,'Kebab',4.85,456),(null,'Couscous',14.25,123),(null,'Burger',3.50,478),(null,'Salade',2.90,100);
