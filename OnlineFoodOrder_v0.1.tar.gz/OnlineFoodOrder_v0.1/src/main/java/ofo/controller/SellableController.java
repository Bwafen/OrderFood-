package ofo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import ofo.repos.CategoryRepository;
import ofo.repos.ComboRepository;
import ofo.repos.FoodItemRepository;
import ofo.repos.SellableRepository;

@Controller
public class SellableController {
	
	@Autowired
	private SellableRepository sellableRepo;
	
	@Autowired
	private FoodItemRepository foodItemRepo;
	
	@Autowired
	private ComboRepository comboRepo;
	
	@Autowired
	private CategoryRepository catRepo;
	
	
	@GetMapping("/admin/catalogue")
	public ModelAndView displaySellables(ModelAndView mv) {
		//TODO Grab Sellables list from repo and inject
		mv.setViewName("sellable/displaySellables");
		return mv;
	}
	
	@GetMapping("/admin/ajout")
	public ModelAndView displayAddForm(ModelAndView mv) {
		mv.setViewName("sellable/createForm");
		return mv;
	}
	
	@PostMapping("/admin/ajout")
	public ModelAndView handleAddForm(ModelAndView mv) {
		mv.setViewName("sellable/createForm");
		return mv;	
	}
	
	@GetMapping("/admin/maj")
	public ModelAndView displayUpdateForm(ModelAndView mv) {
		mv.setViewName("sellable/updateForm");
		return mv;
	}
	
	@PostMapping("/admin/maj")
	public ModelAndView handleUpdateForm(ModelAndView mv) {
		mv.setViewName("sellable/updateForm");
		return mv;
	}
	
	@PostMapping("/recherche")
	public ModelAndView searchSellables(ModelAndView mv, 
										@RequestParam (name="description") String desc) {
		mv.addObject("desc", desc);
		List<Sellable>sellables = sellableRepo.findByDescriptionContaining(desc);
		mv.addObject("sellables",sellables);		
		mv.setViewName("sellable/displaySearchResult");
		//mv.addObject("message", desc);
		return mv;
	}
	
}
