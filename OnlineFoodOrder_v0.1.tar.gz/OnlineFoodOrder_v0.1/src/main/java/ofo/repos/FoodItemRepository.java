package ofo.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ofo.model.FoodItem;

public interface FoodItemRepository extends JpaRepository<FoodItem, Integer>{
	public List<FoodItem> findByDescriptionContaining();
}
