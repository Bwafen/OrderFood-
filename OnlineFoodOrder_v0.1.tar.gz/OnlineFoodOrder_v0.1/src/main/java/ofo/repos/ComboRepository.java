package ofo.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ofo.model.Combo;

public interface ComboRepository extends JpaRepository<Combo, Integer>{
	public List<Combo> findByDescriptionContaining();
}
