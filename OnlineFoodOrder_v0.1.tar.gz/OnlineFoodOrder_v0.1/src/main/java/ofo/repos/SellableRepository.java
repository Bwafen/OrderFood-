package ofo.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import ofo.model.Sellable;

public interface SellableRepository extends JpaRepository<Sellable,Integer>{
	public List<Sellable> findByDescriptionContaining();
}
