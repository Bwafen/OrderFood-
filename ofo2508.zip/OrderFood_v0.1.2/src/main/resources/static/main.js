$(function() {
	//console.log("jQuery activated");
	
	//Setting csrf header for all AJAX requests
	let csrfHeader = $("meta[name='csrfHeader']").attr("content");	
	let csrfToken = $("meta[name='csrfToken']").attr("content");
	//console.log(csrfHeader,csrfToken);
	$(document).ajaxSend(function (evt,xhr,options) {
		xhr.setRequestHeader(csrfHeader,csrfToken);
	});
	
	
	//Deleting a sellable
	$(".deleteSellableBtn").on("click", function(evt){
		evt.preventDefault();
		console.log("deleteSellableBtn pressed");
		//Send POST request to url mapped to deletion method in controller
		let delUrl = this.href; //This being the element we clicked on, triggering the event.
		let redirectUrl = $(this).attr("redirect-url");
		//console.log(redirectUrl);
		//console.log(delUrl);
		$.post(delUrl, function(data){
			console.log(data);
			if(data){				
				window.location.href=redirectUrl;
				alert("Produit supprimé");	
			}else {
				alert("Yep. We got a problem.");
			}
		});
	});
	
	
	
});