INSERT INTO categories(id,name) VALUES(null,'légumes'),(null,'fruits'),(null,'spicy');
INSERT INTO sellables(id,description,price) VALUES(null,'Kebab',4.85),(null,'Couscous',14.25),(null,'Burger',3.50),(null,'Salade',2.90),(null,'Bière',3.45),(null,'Eau gazeuse',1.90);
INSERT INTO fooditems(id,quantity) VALUES(1,100),(2,150),(3,200),(4,600),(5,666),(6,123);

