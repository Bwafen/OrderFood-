package ofo.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import ofo.model.Category;
import ofo.model.Combo;
import ofo.model.FoodItem;
import ofo.model.Sellable;
import ofo.repos.CategoryRepository;
import ofo.repos.ComboRepository;
import ofo.repos.FoodItemRepository;
import ofo.repos.SellableRepository;


@Controller
public class SellableController {
	
	@Autowired
	private SellableRepository sellableRepo;	
	@Autowired
	private FoodItemRepository foodItemRepo;	
	@Autowired
	private ComboRepository comboRepo;
	@Autowired
	private CategoryRepository catRepo;
	
	Logger logger = LoggerFactory.getLogger(SellableController.class);
	
	
	@GetMapping("/admin/catalogue")
	public ModelAndView displaySellablesList(ModelAndView mv) {
		//TODO Grab Sellables list from repo and inject
		List<Sellable> allSellables= sellableRepo.findAll();
		mv.addObject("sellables", allSellables);
		mv.setViewName("sellable/displaySellablesList");
		return mv;
	}
	
	@GetMapping({"/menu/{id}","/produit/{id}"})
	public ModelAndView displaySellable(ModelAndView mv, @RequestParam String id) {
		mv.setViewName("sellalbe/displaySellable");
		return mv;
	}
	
	@GetMapping("/admin/ajoutproduit")
	public ModelAndView displayAddFoodItemForm(ModelAndView mv) {
		List<Category> categories= catRepo.findAll();
		FoodItem food = new FoodItem();
		mv.addObject("foodItem", food);
		mv.addObject("catList", categories);
		mv.setViewName("sellable/createFoodItemForm");
		return mv;
	}
	
	@PostMapping("/admin/ajoutproduit")
	//TODO
	public ModelAndView handleAddFoodItemForm(@Valid FoodItem foodItem, 
													BindingResult errors, ModelAndView mv) {
		if(! errors.hasErrors()) {
			foodItemRepo.save(foodItem);
		}
		mv.setViewName("redirect:/admin/catalogue");
		return mv;	
	}
	
	@GetMapping("/admin/ajoutmenu")
	public ModelAndView displayAddComboForm(ModelAndView mv) {
		List<Category> categories = catRepo.findAll();
		List<FoodItem> foodItems = foodItemRepo.findAll();
		Combo combo = new Combo();
		mv.addObject("combo", combo);
		mv.addObject("foodItems", foodItems);
		mv.addObject("catList", categories);
		mv.setViewName("sellable/createComboItemForm");
		return mv;
	}
	
	@PostMapping("/admin/ajoutmenu")
	//TODO
	public ModelAndView handleAddComboForm(ModelAndView mv) {
		mv.setViewName("sellable/createComboItemForm");
		return mv;	
	}
	
	@GetMapping("/admin/maj/{id}")
	public ModelAndView displayUpdateForm(ModelAndView mv,@PathVariable int id) {
		Optional<Sellable> sellableMaybe= sellableRepo.findById(id);
		Sellable sellable = sellableMaybe.get();
		mv.addObject("sellable", sellable);
		mv.setViewName("sellable/updateForm");
		return mv;
	}
	
	@PostMapping("/admin/maj/{id}")
	//TODO
	public ModelAndView handleUpdateForm(ModelAndView mv) {
		mv.setViewName("sellable/updateForm");
		return mv;
	}
	
	@PostMapping("/admin/supprimer/{id}")
	@ResponseBody
	public boolean handleDeleteForm(@PathVariable int id) {
		try {			
			sellableRepo.deleteById(id);
			return true;
		}catch(Exception e) {
			return false;
		}
	}
	
	@PostMapping("/recherche")
	public ModelAndView searchSellables(ModelAndView mv, 
										@RequestParam (name="description") String desc) {
		mv.addObject("desc", desc);
		List<FoodItem>sellables = foodItemRepo.findByDescriptionContaining(desc);
		mv.addObject("sellables",sellables);		
		mv.setViewName("sellable/displaySearchResult");
		//mv.addObject("message", desc);
		return mv;
	}
	
}
