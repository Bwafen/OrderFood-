package ofo.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="fooditems")
public class FoodItem extends Sellable {
	
	@ManyToMany
	private List<Category> categories;
	@Min(0)
	@NotNull(message="quantity can't be null")
	private int quantity;
	
	/*public FoodItem() {
		this.categories = new ArrayList<Category>();
	}*/

	public List<Category> getCategories() {
		return categories;
	}

	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	
}
