package ofo.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="Combos")
public class Combo extends Sellable {
	@NotNull(message="It's a menu. We should know what's in it.")
	@ManyToMany
	private List<FoodItem> contents;
	@ManyToMany
	private List<Category> categories;

	public List<FoodItem> getContents() {
		return contents;
	}

	public void setContents(List<FoodItem> contents) {
		this.contents = contents;
	}

	public List<Category> getCategories() {
		return categories;
	}

	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}
		

}
