package ofo.repos;

import ofo.model.Sellable;

public interface SellableRepository extends SellableBaseRepository<Sellable>{
	
}
