package ofo.repos;

import ofo.model.Category;
import ofo.model.Sellable;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface SellableBaseRepository <Type extends Sellable> extends JpaRepository<Type, Integer>{
	public List<Type> findByDescriptionContaining(String desc);

}
