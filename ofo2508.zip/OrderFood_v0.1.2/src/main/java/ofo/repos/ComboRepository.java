package ofo.repos;

import ofo.model.Combo;

public interface ComboRepository extends SellableBaseRepository<Combo>{
	
}
