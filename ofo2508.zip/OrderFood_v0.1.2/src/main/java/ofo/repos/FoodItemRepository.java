package ofo.repos;

import ofo.model.FoodItem;

public interface FoodItemRepository extends SellableBaseRepository<FoodItem>{
	
}
